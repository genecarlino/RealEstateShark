from django.apps import AppConfig


class StaffmanagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'staffManagement'
